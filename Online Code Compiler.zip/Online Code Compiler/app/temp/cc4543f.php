<?php 

$i = 2;
$j = 3;

if($i < $j) echo "Hello";
else echo "Hi";